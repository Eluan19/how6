from flask import Flask, render_template, request, redirect, flash, url_for, jsonify
import oracledb
import secrets

print(secrets.token_hex(16))

app = Flask(__name__)
app.secret_key = 'flask_eluan_chave_segura_2025'

# Configurações do banco Oracle
db_config = {
    "user": "USUARIO",
    "password": "SENHA",
    "dsn": "localhost:5555/root"
}

# Função de conexão (pode ser usada em outras rotas)
def get_connection():
    try:
        conn = oracledb.connect(**db_config)
        return conn
    except Exception as e:
        print("Erro ao conectar ao Oracle:", e)
        return None

@app.route('/')
def portal():
    pedidos_recentes = buscar_pedidos_recentes()  # função que retorna os últimos pedidos
    return render_template('portal.html', pedidos_recentes=pedidos_recentes)

def buscar_pedidos_recentes():
    conn = oracledb.connect(**db_config)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT IDPEDIDO, DATAPEDIDO, NOMEPARC, STATUS 
        FROM TGFPEDIDO 
        ORDER BY DATAPEDIDO DESC 
        FETCH FIRST 5 ROWS ONLY
    """)

    colunas = [desc[0] for desc in cursor.description]
    resultados = [dict(zip(colunas, linha)) for linha in cursor.fetchall()]

    cursor.close()
    conn.close()
    return resultados

# Página de adicionar produto (novo produto)
@app.route('/novos-produtos/nv-produtos')
def nv_produtos():
    return render_template('novos-produtos/nv-produtos.html')

# Rota para adicionar produto (novo produto)
@app.route('/novos-produtos/nv-produtos', methods=['GET', 'POST'])
def nv_produtos1():
    if request.method == 'POST':
        nome = request.form.get('nome')
        descricao = request.form.get('descricao')
        categoria = request.form.get('categoria')
        preco = request.form.get('preco')
        estoque = request.form.get('estoque')
        codigo = request.form.get('codigo')

        # Validação simples
        if not all([nome, descricao, categoria, preco, estoque, codigo]):
            return redirect(url_for('nv_produtos') + '?message=Produto+salvo+com+sucesso&category=success')

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO TGFPROVEN (NOMEPROD, DESCRICAOPROD, CATEGORIA, PRECO, ESTOQUEINI, CODINTERNO)
                VALUES (:1, :2, :3, :4, :5, :6)
            """, (nome, descricao, categoria, float(preco), float(estoque), int(codigo)))
            conn.commit()
            cur.close()
            conn.close()
            return redirect(url_for('nv_produtos') + '?message=Produto+salvo+com+sucesso&category=success')

        except Exception as e:
            print("Erro ao inserir produto:", e)
            return redirect(url_for('nv_produtos') + '?message=Produto+salvo+com+sucesso&category=success')

    return render_template('novos-produtos/nv-produtos.html')

# Página de produtos
'''@app.route('/produtos/produtos')
def produtos():
    return render_template('produtos/produtos.html')'''

# Verificar todos produtos
@app.route('/produtos/produtos')
def produtos1():
    try:
        conn = get_connection()
        cur = conn.cursor()

        # Pega todas as categorias distintas para o filtro
        cur.execute("SELECT DISTINCT CATEGORIA FROM TGFPROVEN ORDER BY CATEGORIA")
        categorias = [row[0] for row in cur.fetchall()]

        filtro_categoria = request.args.get('categoria')
        
        if filtro_categoria:
            query = """
                SELECT NOMEPROD, DESCRICAOPROD, CATEGORIA, PRECO, ESTOQUEINI, CODINTERNO
                FROM TGFPROVEN
                WHERE CATEGORIA = :1
                ORDER BY NOMEPROD
            """
            cur.execute(query, [filtro_categoria])
        else:
            query = """
                SELECT NOMEPROD, DESCRICAOPROD, CATEGORIA, PRECO, ESTOQUEINI, CODINTERNO
                FROM TGFPROVEN
                ORDER BY NOMEPROD
            """
            cur.execute(query)
        
        produtos = cur.fetchall()  # <-- APENAS AQUI!

        print(f"{len(produtos)} produtos encontrados.")
        for p in produtos:
            print(p)

        cur.close()
        conn.close()

        return render_template(
            'produtos/produtos.html',
            produtos=produtos,
            categorias=categorias,
            filtro_categoria=filtro_categoria
        )

    except Exception as e:
        print("Erro ao carregar produtos:", e)
        return "Erro ao carregar produtos."

# Página HTML de clientes
@app.route('/clientes/clientes')
def clientes_html():
    return render_template('clientes/clientes.html')

# Rota de dados JSON dos clientes
@app.route('/clientes/clientes1')
def clientes1():
    estado = request.args.get('estado')
    conn = get_connection()
    cur = conn.cursor()

    if estado:
        cur.execute("SELECT * FROM TGFPARVEN WHERE ESTADO = :1", (estado,))
    else:
        cur.execute("SELECT * FROM TGFPARVEN")

    colunas = [i[0] for i in cur.description]
    dados = [dict(zip(colunas, linha)) for linha in cur.fetchall()]
    
    cur.close()
    conn.close()
    return jsonify(dados)

#Rota para novs clientes
@app.route('/nv-clientes/nv-clientes')
def nv_clientes():
    return render_template('nv-clientes/nv-clientes.html')

@app.route('/nv-clientes/nv-clientes', methods=['POST'])
def nv_clientes1():
    try:
        data = request.get_json()

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("SELECT NVL(MAX(CODCLIENTEVEN), 0) + 1 FROM TGFPARVEN")
        novo_codigo = cur.fetchone()[0]

        cur.execute("""
            INSERT INTO TGFPARVEN (
                CODCLIENTEVEN, RAZAOSOCIAL, NOMECLIENTE,
                ESTADO, CIDADE, ENDERECO, NUMEROTEL
            ) VALUES (
                :1, :2, :3, :4, :5, :6, :7
            )
        """, (
            novo_codigo,
            data['razaosocial'],
            data['nomecliente'],
            data['estado'],
            data['cidade'],
            data['endereco'],
            data['numerotel']
        ))

        conn.commit()
        cur.close()
        conn.close()

        return 'OK', 200

    except Exception as e:
        print("Erro ao inserir cliente:", e)
        return 'Erro', 500
    
@app.route('/novo-pedido/novo-pedido')
def novo_pedido():
    return render_template('novo-pedido/novo-pedido.html')

@app.route('/produtos/json')
def produtos_json():
    try:
        conn = get_connection()
        cur = conn.cursor()

        query = """
            SELECT CODPROD, NOMEPROD, PRECO
            FROM TGFPROVEN
            ORDER BY NOMEPROD
        """
        cur.execute(query)
        produtos = cur.fetchall()
        cur.close()
        conn.close()

        return jsonify([
            {
                'CODPROD': row[0],
                'NOMEPROD': row[1],
                'PRECO': float(row[2])
            } for row in produtos
        ])

    except Exception as e:
        print("Erro ao carregar produtos JSON:", e)
        return jsonify([]), 500
    
@app.route('/clientes/novo-pedido')
def clientes_para_novo_pedido():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT CODCLIENTEVEN, RAZAOSOCIAL FROM TGFPARVEN")
        clientes = [{"CODCLIENTEVEN": row[0], "RAZAOSOCIAL": row[1]} for row in cur.fetchall()]
        cur.close()
        conn.close()
        return jsonify(clientes)
    except Exception as e:
        print("Erro ao buscar clientes:", e)
        return jsonify([]), 500

@app.route('/pedidos/novo', methods=['POST'])
def salvar_pedido():
    data = request.get_json()

    data_pedido = data.get('datapedido')
    id_cliente = int(data.get('idcliente'))
    produtos = data.get('produtos', [])

    if not id_cliente or not produtos:
        return jsonify({"status": "erro", "mensagem": "Informe o cliente e ao menos 1 produto válido."}), 400

    try:
        conn = oracledb.connect(**db_config)
        cursor = conn.cursor()

        # Gerar novo IDPEDIDO
        cursor.execute("SELECT NVL(MAX(IDPEDIDO), 0) + 1 FROM TGFPEDIDO")
        id_pedido = cursor.fetchone()[0]

        # Buscar nome do cliente
        cursor.execute("SELECT RAZAOSOCIAL FROM TGFPARVEN WHERE CODCLIENTEVEN = :id", {'id': id_cliente})
        row = cursor.fetchone()
        nome_parc = row[0] if row else 'Cliente Desconhecido'

        # Calcular total do pedido
        total = 0.0

        # Verificar estoque de todos os produtos primeiro
        for p in produtos:
            cod_prod = int(p['codigo'])
            quantidade = float(p['quantidade'])

            cursor.execute("SELECT ESTOQUEINI FROM TGFPROVEN WHERE CODPROD = :id", {'id': cod_prod})
            result = cursor.fetchone()

            if not result:
                raise Exception(f"Produto {cod_prod} não encontrado no estoque.")

            estoque_atual = float(result[0])
            if quantidade > estoque_atual:
                raise Exception(f"Estoque insuficiente para o produto {cod_prod}. Estoque atual: {estoque_atual}, solicitado: {quantidade}")

        # Inserir o pedido principal
        for p in produtos:
            quantidade = float(p['quantidade'])
            valor_unit = float(p['valor'])
            total += quantidade * valor_unit

        cursor.execute("""
            INSERT INTO TGFPEDIDO (IDPEDIDO, DATAPEDIDO, IDCLIENTE, NOMEPARC, STATUS, VLRTOTAL)
            VALUES (:id, TO_DATE(:data, 'YYYY-MM-DD'), :cliente, :nome, :status, :total)
        """, {
            'id': id_pedido,
            'data': data_pedido,
            'cliente': id_cliente,
            'nome': nome_parc,
            'status': 'PENDENTE',
            'total': total
        })

        # Inserir itens e atualizar estoque
        for item in produtos:
            cod_prod = int(item['codigo'])
            quantidade = float(item['quantidade'])
            valor_unit = float(item['valor'])

            # Inserir item
            cursor.execute("""
                INSERT INTO TGFITEMPED (IDPEDIDO, IDPRODUTO, QUANTIDADE, PRECOUNITARIO)
                VALUES (:id_pedido, :id_prod, :quantidade, :valor_unit)
            """, {
                'id_pedido': id_pedido,
                'id_prod': cod_prod,
                'quantidade': quantidade,
                'valor_unit': valor_unit
            })

            # Subtrair do estoque
            cursor.execute("""
                UPDATE TGFPROVEN
                SET ESTOQUEINI = ESTOQUEINI - :qtd
                WHERE CODPROD = :id_prod
            """, {
                'qtd': quantidade,
                'id_prod': cod_prod
            })

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"status": "sucesso", "id_pedido": id_pedido}), 200

    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
@app.route('/pedidos/pedidos')
def listar_pedidos():
    conn = oracledb.connect(**db_config)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT IDPEDIDO, DATAPEDIDO, IDCLIENTE, NOMEPARC, STATUS, VLRTOTAL
        FROM TGFPEDIDO
        ORDER BY IDPEDIDO DESC
    """)
    colnames = [col[0] for col in cursor.description]
    pedidos = [dict(zip(colnames, row)) for row in cursor.fetchall()]

    cursor.close()
    conn.close()
    return render_template('pedidos/pedidos.html', pedidos=pedidos)

@app.route('/pedidos/atualizar-status', methods=['POST'])
def atualizar_status():
    id_pedido = request.form.get('id_pedido')
    conn = oracledb.connect(**db_config)
    cursor = conn.cursor()

    cursor.execute("UPDATE TGFPEDIDO SET STATUS = 'FATURADO' WHERE IDPEDIDO = :1", [id_pedido])
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('/pedidos/pedidos')

@app.route('/pedidos/detalhes<int:id_pedido>')
def detalhes_pedido(id_pedido):
    conn = oracledb.connect(**db_config)
    cursor = conn.cursor()

    # Dados do pedido
    cursor.execute("""
        SELECT P.IDPEDIDO, P.DATAPEDIDO, P.IDCLIENTE, PAR.RAZAOSOCIAL, P.STATUS, P.VLRTOTAL
        FROM TGFPEDIDO P
        LEFT JOIN TGFPARVEN PAR ON PAR.CODCLIENTEVEN = P.IDCLIENTE
        WHERE P.IDPEDIDO = :1
    """, [id_pedido])
    row = cursor.fetchone()
    colnames = [col[0] for col in cursor.description]
    pedido = dict(zip(colnames, row)) if row else None

    # Itens do pedido
    cursor.execute("""
        SELECT I.IDPRODUTO, PRO.NOMEPROD, I.QUANTIDADE, I.PRECOUNITARIO
        FROM TGFITEMPED I
        JOIN TGFPROVEN PRO ON PRO.CODPROD = I.IDPRODUTO
        WHERE I.IDPEDIDO = :1
    """, [id_pedido])
    colnames_itens = [col[0] for col in cursor.description]
    itens = [dict(zip(colnames_itens, row)) for row in cursor.fetchall()]

    cursor.close()
    conn.close()

    return render_template('pedidos/detalhes/detalhes.html', pedido=pedido, itens=itens)

@app.route('/pedidos/pedidos')
def pedidos2():
    return render_template('pedidos/pedidos.html')

@app.route('/pedidos/detalhes/detalhes')
def detalhes():
    return render_template('/pedidos/detalhes/detalhes.html')

# Iniciar o servidor Flask
if __name__ == '__main__':
    app.run(debug=True)
